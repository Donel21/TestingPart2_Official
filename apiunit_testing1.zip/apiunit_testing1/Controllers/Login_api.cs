﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace apiunit_testing1.Controllers
{//start of namespace
    [Route("api/[controller]")]
    [ApiController]
    public class Login_api : ControllerBase
    {// start of class

        //request method for login Endpoint
        //using HttpGet
        [HttpGet]
        public string login(string email, string password)
        {//start of method 

            //if statement to check if
            //email and password are correct

            if (email.ToLower().Contains("@gmail.com") && password.Length >= 8)
            {

                //return login succesfully
                return "login successfully";
            }
            else 
            {

                //return incorrect email or password
                return "incorrect email or password";
            }

        }//end of the method

    }//end of class
}//end of namespace
